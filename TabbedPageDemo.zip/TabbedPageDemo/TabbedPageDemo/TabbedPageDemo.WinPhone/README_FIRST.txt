For the Windows Phone toolkit make sure that you have
marked the icons in the "Toolkit.Content" folder as content.  That way they 
can be used as the icons for the ApplicationBar control.